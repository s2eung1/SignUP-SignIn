import java.awt.BorderLayout;
import java.awt.EventQueue;

import javax.swing.JFrame;
import javax.swing.JPanel;
import javax.swing.border.EmptyBorder;
import javax.swing.JButton;
import java.awt.Font;
import javax.swing.SwingConstants;
import javax.swing.JTextField;
import java.awt.Panel;
import java.awt.Color;
import java.awt.Button;
import javax.swing.JLabel;
import java.awt.Label;
import javax.swing.ImageIcon;
import java.awt.event.MouseAdapter;
import java.awt.event.MouseEvent;
import java.awt.event.ActionListener;
import java.awt.event.ActionEvent;

public class Menu extends JFrame {

	private JPanel contentPane;

	//public static void main(String[] args) {
	//	EventQueue.invokeLater(new Runnable() {
	//		public void run() {
	//			try {
	//				Menu frame = new Menu();
	//				frame.setVisible(true);
	//			} catch (Exception e) {
	//				e.printStackTrace();
	//			}
	//		}
	//	});
	//}

	/**
	 * Create the frame.
	 */
	public Menu() {
		this.setTitle("SOFTWARE INFORMATION");
		
		setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		setBounds(205, 100, 900, 567);
		contentPane = new JPanel();
		contentPane.setBackground(new Color(62, 60, 61));
		contentPane.setBorder(new EmptyBorder(5, 5, 5, 5));
		setContentPane(contentPane);
		contentPane.setLayout(null);
		
		Panel panel = new Panel();
		panel.setBounds(0, 0, 878, 511);
		contentPane.add(panel);
		panel.setLayout(null);
		
		JPanel panel_1 = new JPanel();
		panel_1.setBounds(0, 0, 442, 511);
		panel.add(panel_1);
		panel_1.setBackground(new Color(254, 210, 89));
		panel_1.setLayout(null);
		
		Label label = new Label("SOFTWARE INFORMATION");
		label.setFont(new Font("Dialog", Font.PLAIN, 30));
		label.setAlignment(Label.CENTER);
		label.setBounds(10, 90, 410, 116);
		panel_1.add(label);
		
		JLabel lblNewLabel = new JLabel("New label");
		lblNewLabel.setIcon(new ImageIcon(Menu.class.getResource("/images/cbnulogo.png")));
		lblNewLabel.setBounds(130, 201, 181, 210);
		panel_1.add(lblNewLabel);
		
		Button button = new Button("\uAD50\uC218 \uC815\uBCF4");
		button.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent arg0) {
				
			}
		});
		button.addMouseListener(new MouseAdapter() {
			@Override
			public void mouseClicked(MouseEvent arg0) {
				new Professor_List();
			}
		});
		button.setBackground(new Color(254, 210, 89));
		button.setFont(new Font("Dialog", Font.PLAIN, 30));
		button.setBounds(517, 48, 278, 118);
		panel.add(button);
		
		Button button_1 = new Button("\uD559\uC0AC \uC77C\uC815");
		button_1.setBackground(new Color(254, 210, 89));
		button_1.setFont(new Font("Dialog", Font.PLAIN, 30));
		button_1.setBounds(517, 193, 278, 118);
		panel.add(button_1);
		
		Button button_2 = new Button("\uC878\uC5C5 \uC694\uAC74");
		button_2.setBackground(new Color(254, 210, 89));
		button_2.setFont(new Font("Dialog", Font.PLAIN, 30));
		button_2.setBounds(517, 339, 278, 118);
		panel.add(button_2);
	}
}
