import java.awt.BorderLayout;
import java.awt.event.*;
import java.util.*;
import javax.swing.*;
import javax.swing.table.DefaultTableModel;

public class Professor_List extends JFrame implements MouseListener, ActionListener{
	Vector v;
	Vector cols;
	DefaultTableModel model;
	JTable jTable;
	JScrollPane pane;
	JPanel pbtn;
	JButton btnInsert;
	
	public Professor_List() {
		super("��������");
		ProfessorDAO dao = new ProfessorDAO();
		v=dao.getProfessorList();
		System.out.println("v="+v);
		cols=getColumn();
		
		model=new DefaultTableModel(v,cols);
		
		jTable=new JTable(model);
		pane=new JScrollPane(jTable);
		add(pane);
		
		jTable.addMouseListener(this);
		//btnInsert.addActionListener(this);
		
		setSize(900,567);
		setVisible(true);
		setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
	}
	
	public Vector getColumn() {
		Vector col=new Vector();
		col.add("�̸�");
		col.add("������");
		col.add("������ ��ȭ��ȣ");
		col.add("�̸���");
		
		return col;
	}
	
	public void jTableRefresh() {
		ProfessorDAO dao=new ProfessorDAO();
		DefaultTableModel model=new DefaultTableModel(dao.getProfessorList(),getColumn());
		jTable.setModel(model);
	}
	
	public static void main(String[] args) {
		new Professor_List();
	}

	@Override
	public void actionPerformed(ActionEvent arg0) {
		// TODO Auto-generated method stub
		
	}

	@Override
	public void mouseClicked(MouseEvent arg0) {
		// TODO Auto-generated method stub
		
	}

	@Override
	public void mouseEntered(MouseEvent arg0) {
		// TODO Auto-generated method stub
		
	}

	@Override
	public void mouseExited(MouseEvent arg0) {
		// TODO Auto-generated method stub
		
	}

	@Override
	public void mousePressed(MouseEvent arg0) {
		// TODO Auto-generated method stub
		
	}

	@Override
	public void mouseReleased(MouseEvent arg0) {
		// TODO Auto-generated method stub
		
	}
	
	
	
}
