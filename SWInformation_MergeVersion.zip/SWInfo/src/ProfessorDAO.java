import java.sql.*;
import java.util.Vector;

import javax.swing.table.DefaultTableModel;

//DB ó��
public class ProfessorDAO {
	private static final String DRIVER="com.mysql.jdbc.Driver";
	private static final String URL="jdbc:mysql://localhost:3306/swinfo";
	
	private static final String USER="root";
	private static final String PASS="1234";
	Professor_List pList;
	
	public ProfessorDAO() {
		
	}
	
	public ProfessorDAO(Professor_List pList) {
		this.pList=pList;
		System.out.println("DAO=>"+pList);
	}
	/*DB���� �޼ҵ�*/
	public Connection getConn() {
		Connection con = null;
		
		try {
			Class.forName(DRIVER);
			con=DriverManager.getConnection(URL,USER,PASS);
		}catch(Exception e) {
			e.printStackTrace();
		}
		
		return con;
	}
	/*�ѻ���� ���������� ��� �޼ҵ�*/
	public ProfessorDTO getProfessorDTO(String name) {
		ProfessorDTO dto=new ProfessorDTO();
		
		Connection con=null;
		PreparedStatement ps=null;
		ResultSet rs=null;
		
		try {
			con=getConn();
			String sql="select*from professor where name=?";
			ps=con.prepareStatement(sql);
			ps.setString(1, name);
			
			rs=ps.executeQuery();
			
			if(rs.next()) {
				dto.setName(rs.getString("name"));
				dto.setRoom(rs.getString("room"));
				dto.setRoom_tel(rs.getString("room_tel"));
				dto.setEmail(rs.getString("email"));
			}
		} catch(Exception e) {
			e.printStackTrace();
		}
		
		return dto;
	}
	/*��������Ʈ ���*/
	public Vector getProfessorList() {
		Vector data=new Vector();
		
		Connection con=null;
		PreparedStatement ps=null;
		ResultSet rs = null;
		
		try {
			con=getConn();
			String sql="select*from professor order by name asc";
			ps=con.prepareStatement(sql);
			rs=ps.executeQuery();
			
			while(rs.next()) {
				String name=rs.getString("name");
				String room=rs.getString("room");
				String room_tel=rs.getString("room_tel");
				String email=rs.getString("email");
				
				Vector row=new Vector();
				row.add(name);
				row.add(room);
				row.add(room_tel);
				row.add(email);
				
				data.add(row);
			}
		}catch(Exception e) {
			e.printStackTrace();
		}
		return data;
	}
	/*�������� �Է�*/
	public boolean insertProfessor(ProfessorDTO dto) {
		boolean ok=false;
		
		Connection con=null;
		PreparedStatement ps=null;
		
		try {
			con=getConn();
			String sql="insert into professor("+"name,room,room_tel,email"+")values(?,?,?,?,?)";
			
			ps=con.prepareStatement(sql);
			ps.setString(1, dto.getName());
			ps.setString(2, dto.getRoom());
			ps.setString(3, dto.getRoom_tel());
			ps.setString(4, dto.getEmail());
			
			int r=ps.executeUpdate();
			
			if(r>0) {
				System.out.println("�Է� ����");
				ok=true;
			}else {
				System.out.println("�Է� ����");
			}
		}catch(Exception e) {
			e.printStackTrace();
		}
		
		return ok;
	}
	/*�������� ����*/
	public boolean updateProfessor(ProfessorDTO vPro) {
		System.out.println("dto="+vPro.toString());
		boolean ok=false;
		Connection con=null;
		PreparedStatement ps=null;
		try {
			con=getConn();
			String sql="update professor set room=?, room_tel=?, email=? where name=?";
			
			ps=con.prepareStatement(sql);
			
			ps.setString(1, vPro.getName());
			ps.setString(2, vPro.getRoom());
			ps.setString(3, vPro.getRoom_tel());
			ps.setString(4, vPro.getEmail());
			
			int r=ps.executeUpdate();
			
			if(r>0) ok=true;
		}catch(Exception e) {
			e.printStackTrace();
		}
		
		return ok;
	}
	/*�������� ����*/
	public boolean deleteProfessor(String name) {
		boolean ok=false;
		Connection con=null;
		PreparedStatement ps=null;
		
		try {
			con=getConn();
			String sql="delete from professor where name=?";
			
			ps=con.prepareStatement(sql);
			ps.setString(1, name);
			
			int r=ps.executeUpdate();
			
			if(r>0)ok=true;
		} catch(Exception e) {
			System.out.println(e+"-> �����߻�");
		}
		return ok;
	}
	/*DB ������ �ٽ� �ҷ�����*/
	public void userSelectAll(DefaultTableModel model) {
		Connection con=null;
		PreparedStatement ps=null;
		ResultSet rs=null;
		
		try {
			con=getConn();
			String sql="select*from professor order by name asc";
			ps=con.prepareStatement(sql);
			rs=ps.executeQuery();
			
			for(int i=0;i<model.getRowCount();) {
				model.removeRow(0);
			}
			
			while(rs.next()) {
				Object data[]= {rs.getString(1), rs.getString(2), rs.getString(3), rs.getString(4)};
				
				model.addRow(data);
			}
		}catch(SQLException e) {
			System.out.println(e+"=> userSelectAll fail");
		}finally {
			if(rs!=null)
				try {
					rs.close();
				}catch(SQLException e2) {
					e2.printStackTrace();
				}
			if(ps!=null)
				try {
					ps.close();
				}catch(SQLException e1) {
					e1.printStackTrace();
				}
			if(con!=null)
				try {
					con.close();
				}catch(SQLException e) {
					e.printStackTrace();
				}
		}
	}
}
